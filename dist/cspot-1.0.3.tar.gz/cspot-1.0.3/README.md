# cspot
 CELL SPOTTER (CSPOT): A scalable framework for automated processing of highly multiplexed tissue images
